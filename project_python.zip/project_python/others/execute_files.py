# -*- coding: utf-8 -*-
import re
import sys
from project_python.main import ProjectPython

project_python = ProjectPython()
project_python.main()